export const environment = {
  production: false,
  salesforce: {
    loginUrl:
      'https://novigosolutionspvtltd2-dev-ed.develop.my.salesforce-sites.com',
    clientId:
      '3MVG9PwZx9R6_UreJ7pGOqAjPactZ4PlE.3xrcLSvO1smOsk4K0cCDaCjEJdqUDyaUXwtYrEElDjSAxRVfMy9',
    clientSecret:
      '8B671E68B5D8679368FE2C97B813DDA073DA4714564622B02D8CC38A11D37EF0',
    redirectUri:
      'https://novigosolutionspvtltd2-dev-ed.develop.my.salesforce-sites.com/',
    apiVersion: 'v62.0', // Use the latest version
    salesforceApiBaseUrl:'https://novigosolutionspvtltd2-dev-ed.develop.my.salesforce-sites.com/services/apexrest'
  },
  huggingFaceApiKey: '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',  // Add this line
};

import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  templateUrl: './dashboard-component.component.html'
})
export class DashboardComponent {
  // Component logic here
}
